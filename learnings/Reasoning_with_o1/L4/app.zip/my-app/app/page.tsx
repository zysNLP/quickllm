import FeedbackForm from './components/FeedbackForm'

export default function Home() {
  return (
    <main className="container mx-auto py-10">
      <FeedbackForm/>
    </main>
  )
}
